<?php
header('Location: doc.html');
?>